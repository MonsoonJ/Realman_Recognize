import pyrealsense2 as rs
import numpy as np
import cv2

# 初始化相机管道和配置
pipeline = rs.pipeline()
config = rs.config()

# 配置深度流（640x480，30帧）
config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
# 配置彩色流（640x480，30帧，与深度流分辨率一致便于拼接）
config.enable_stream(rs.stream.color, 640, 480, rs.format.rgb8, 30)

# 启动相机
pipeline.start(config)

try:
    while True:
        # 获取帧数据
        frames = pipeline.wait_for_frames()
        depth_frame = frames.get_depth_frame()
        color_frame = frames.get_color_frame()

        # 跳过无效帧
        if not depth_frame or not color_frame:
            continue

        # ========== 处理深度画面（左侧） ==========
        depth_image = np.asanyarray(depth_frame.get_data())
        # 深度图彩色编码（便于可视化）
        depth_colormap = cv2.applyColorMap(
            cv2.convertScaleAbs(depth_image, alpha=0.03),
            cv2.COLORMAP_JET
        )

        # ========== 处理全彩画面（右侧） ==========
        color_image = np.asanyarray(color_frame.get_data())
        # 转换RGB→BGR（OpenCV默认显示格式）
        color_image = cv2.cvtColor(color_image, cv2.COLOR_RGB2BGR)

        # ========== 拼接画面（左深度 + 右全彩） ==========
        combined_image = np.hstack((depth_colormap, color_image))

        # 显示画面
        cv2.imshow('D455 (Left: Depth / Right: Color)', combined_image)

        # 按ESC键退出（1ms检测一次按键）
        if cv2.waitKey(1) & 0xFF == 27:
            break

finally:
    # 释放资源
    pipeline.stop()
    cv2.destroyAllWindows()